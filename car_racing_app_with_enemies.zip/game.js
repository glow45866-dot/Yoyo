const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const carImg = new Image();
const roadImg = new Image();

carImg.src = "./assets/car.png";
roadImg.src = "./assets/road.png";

let carX = 175;
let carY = 450;
let speed = 4;
let gameOver = false;

let enemies = [];
const lanes = [50, 175, 300];

function spawnEnemy() {
  enemies.push({ x: lanes[Math.floor(Math.random() * lanes.length)], y: -120 });
}

document.addEventListener("keydown", e => {
  if (e.key === "ArrowLeft" && carX > 0) carX -= 20;
  if (e.key === "ArrowRight" && carX < 350) carX += 20;
});

function crash(a, b) {
  return a.x < b.x + 50 && a.x + 50 > b.x && a.y < b.y + 100 && a.y + 100 > b.y;
}

let spawnTimer = 0;

function gameLoop() {
  if (gameOver) {
    ctx.fillStyle = "red";
    ctx.font = "40px Arial";
    ctx.fillText("GAME OVER", 90, 300);
    return;
  }

  ctx.drawImage(roadImg, 0, 0, 400, 600);
  ctx.drawImage(carImg, carX, carY, 50, 100);

  spawnTimer++;
  if (spawnTimer > 90) {
    spawnEnemy();
    spawnTimer = 0;
  }

  enemies.forEach((enemy, i) => {
    enemy.y += speed;
    ctx.drawImage(carImg, enemy.x, enemy.y, 50, 100);
    if (crash({x:carX,y:carY}, enemy)) gameOver = true;
    if (enemy.y > 600) enemies.splice(i, 1);
  });

  requestAnimationFrame(gameLoop);
}

roadImg.onload = () => gameLoop();